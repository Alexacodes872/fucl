document.addEventListener('DOMContentLoaded', () => {
    function updateWeather() {
        // Simulated weather data
        const location = 'Messadine, Susah, Tunisia';
        const temperature = '23°';
        const date = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric' });

        document.getElementById('location').textContent = location;
        document.getElementById('date').textContent = date;
        document.getElementById('temperature').textContent = temperature;
    }

    updateWeather();
});