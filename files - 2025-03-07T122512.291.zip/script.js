document.addEventListener('DOMContentLoaded', () => {
    const mainContainer = document.getElementById('mainContainer');
    const leftSidebar = document.getElementById('leftSidebar');
    const rightSidebar = document.getElementById('rightSidebar');
    const clockElement = document.getElementById('clock');
    const toggleRgbButton = document.getElementById('toggleRgbButton');
    const setTimeButton = document.getElementById('setTimeButton');
    const closeButton = document.getElementById('closeButton');
    const weatherAppButton = document.getElementById('weatherAppButton');

    const rgbModes = ['Off', 'Girly', 'Boy', 'Gaming', 'On'];
    let currentRgbModeIndex = 0;
    let colorInterval;
    let customTime = null;

    const girlyColors = ['#FFC0CB', '#FF69B4', '#D8BFD8', '#E6E6FA', '#F08080', '#FFE4E1', '#40E0D0'];
    const boyColors = ['#0000FF', '#1E90FF', '#4169E1', '#000080', '#4682B4', '#5F9EA0'];
    const gamingColors = ['#00FF00', '#ADFF2F', '#7FFF00', '#32CD32', '#9ACD32', '#6B8E23'];

    function updateClock() {
        const now = new Date();
        let hours = now.getHours();
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12; // the hour '0' should be '12'
        clockElement.textContent = `${hours}:${minutes} ${ampm}`;
        setTimeout(updateClock, 60000); // Update every minute
    }

    updateClock(); // Start the clock

    function changeBackgroundColor(colors) {
        let index = 0;
        if (colorInterval) clearInterval(colorInterval);
        colorInterval = setInterval(() => {
            document.body.style.backgroundColor = colors[index];
            index = (index + 1) % colors.length;
        }, 1000);
    }

    function toggleRgbMode() {
        currentRgbModeIndex = (currentRgbModeIndex + 1) % rgbModes.length;
        const currentMode = rgbModes[currentRgbModeIndex];
        toggleRgbButton.textContent = `Current Mode: ${currentMode}`;

        switch (currentMode) {
            case 'Girly':
                changeBackgroundColor(girlyColors);
                break;
            case 'Boy':
                changeBackgroundColor(boyColors);
                break;
            case 'Gaming':
                changeBackgroundColor(gamingColors);
                break;
            case 'On':
                changeBackgroundColor([...girlyColors, ...boyColors, ...gamingColors]);
                break;
            default:
                document.body.style.backgroundColor = '#000'; // Default to black for 'Off'
                if (colorInterval) clearInterval(colorInterval);
        }
    }

    function setTime() {
        const hours = parseInt(document.getElementById('hours').value);
        const minutes = parseInt(document.getElementById('minutes').value);
        customTime = new Date();
        if (!isNaN(hours)) customTime.setHours(hours);
        if (!isNaN(minutes)) customTime.setMinutes(minutes);
        updateClock();
    }

    let touchstartX = 0;
    let touchendX = 0;
    let touchstartY = 0;
    let touchendY = 0;

    function handleGesture() {
        const threshold = 100; // Minimum distance for swipe to be detected
        const middleZoneWidth = window.innerWidth / 3;
        const startInMiddle = touchstartX > middleZoneWidth && touchstartX < window.innerWidth - middleZoneWidth;

        const diffX = touchendX - touchstartX;
        const diffY = touchendY - touchstartY;

        if (Math.abs(diffY) > Math.abs(diffX) && Math.abs(diffY) > threshold) {
            if (touchendY < touchstartY) {
                // Swipe bottom to top
                mainContainer.classList.remove('hidden');
                mainContainer.style.top = '50%';
            } else if (startInMiddle && touchendY > touchstartY) {
                // Swipe top to bottom in the middle of the screen
                mainContainer.classList.add('hidden');
                mainContainer.style.top = '-100%';
            }
        } else if (Math.abs(diffX) > threshold) {
            if (touchendX < touchstartX) {
                // Swipe right to left
                rightSidebar.classList.add('visible');
                leftSidebar.classList.remove('visible');
            }
            if (touchendX > touchstartX) {
                // Swipe left to right
                leftSidebar.classList.add('visible');
                rightSidebar.classList.remove('visible');
            }
        }
    }

    document.addEventListener('touchstart', e => {
        touchstartX = e.changedTouches[0].screenX;
        touchstartY = e.changedTouches[0].screenY;
    });

    document.addEventListener('touchend', e => {
        touchendX = e.changedTouches[0].screenX;
        touchendY = e.changedTouches[0].screenY;
        handleGesture();
    });

    // Ensure elements are hidden when clicking outside
    document.addEventListener('click', e => {
        if (!mainContainer.contains(e.target) && 
            !leftSidebar.contains(e.target) && 
            !rightSidebar.contains(e.target)) {
            mainContainer.classList.add('hidden');
            leftSidebar.classList.remove('visible');
            rightSidebar.classList.remove('visible');
            mainContainer.style.top = '-100%';
        }
    });

    // Additional event listeners for specific buttons (if needed)
    document.getElementById('clockButton').addEventListener('click', () => {
        mainContainer.classList.add('hidden');
        leftSidebar.classList.remove('visible');
        rightSidebar.classList.remove('visible');
        document.getElementById('clockFrame').classList.add('visible');
    });

    document.getElementById('mediaPlayerButton').addEventListener('click', () => {
        mainContainer.classList.toggle('hidden');
        if (mainContainer.classList.contains('